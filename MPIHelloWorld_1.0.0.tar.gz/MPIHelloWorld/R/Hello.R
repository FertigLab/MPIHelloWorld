
#' @export
Hello <- function()
{
    Hello_cpp()
}