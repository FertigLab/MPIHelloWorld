#' MPI_HelloWorld
#'
#' Hello World with MPI
#' \tabular{ll}{
#' Package: \tab MPI_HelloWorld\cr
#' Type: \tab Package\cr
#' Version: \tab 1.0.0\cr
#' Date: \tab 2018-06-12\cr
#' License: \tab LGPL\cr
#' }
#' @author Tom Sherman, Tiger Gao
#' @docType package
#' @name MPIHelloWorld-package
#' @useDynLib MPIHelloWorld
NULL