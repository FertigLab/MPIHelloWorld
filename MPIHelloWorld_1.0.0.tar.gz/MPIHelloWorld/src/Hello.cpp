#include <Rcpp.h>

// [[Rcpp::export]]
void Hello_cpp()
{
    Rprintf("Hello World\n");
}
